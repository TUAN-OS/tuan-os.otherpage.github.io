#!/bin/bash
echo Welcome to Tuanminh-OS v1.00, it in the beta and if you can,  help me
echo This is frist version of tuanminh-os, then it is my frist bash code
echo typiyng cd system, cd main
echo then type source /main/[nameofscript.sh]
echo 81 MB/S processor, 194 MB left.
echo $els