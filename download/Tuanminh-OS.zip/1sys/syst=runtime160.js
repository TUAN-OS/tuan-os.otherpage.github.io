console.log ("sysruntime")
exit