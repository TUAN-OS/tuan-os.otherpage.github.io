#!/bin/bash
echo Welcome to Tuanminh-OS v1.00, it in the beta and if you can,  help me
echo This is frist version of tuanminh-os, then it is my frist bash code
echo typiyng cd .., cd main, then bash [nameofscript.sh]
echo then type source /system/main/[nameofscript.sh]
echo 81 MB/S processor, 194 MB left.
echo $els